package com.classe;

import java.io.IOException;


/**
 * 
 * Nom du fichier: Main.java 
 * Date: 29 mars 2017
 * Membres du Projet:
 * Laurent Panek, Abdessamad Douhi
 * Abdessalam Benharira, Branis Lamrani
 * Chef de Projet: Branis Lamrani
 */
public class Main {
	/**
	 * Méthode principale
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Fenetre window = new Fenetre();
		window.defFenetre();

	}

}